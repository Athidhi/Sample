
import { Typography } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import * as React from 'react';

const DeleteDialog = (props: any) => {
    return (
        <div>
            <Dialog open={props.show} onClose={props.onDeleteDiscard}>
                <DialogTitle color={'red'}><i>Deleting Pharmacy {props.data.pharmID}. <br /></i></DialogTitle>
                <DialogContent>
                    <Typography variant='subtitle1'> Are you sure? </Typography>
                </DialogContent>
                <DialogActions>
                    <Button style={{ textTransform: "none" }} variant='contained' color="error" onClick={() => props.onDeleteSubmit(props.data)}>Yes</Button>
                    <Button style={{ textTransform: "none" }} variant='contained' color="success" onClick={props.onDeleteDiscard}>No</Button>
                </DialogActions>
            </Dialog>
        </div>
    );
}
export default DeleteDialog;
