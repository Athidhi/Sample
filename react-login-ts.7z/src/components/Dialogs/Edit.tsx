import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import * as React from 'react';
import { useForm } from 'react-hook-form';
import { StoreThrottle } from '../../model/throttle';
import { FormInputText } from '../FormElements/FormInputText';
interface Iprops {
  onEditSubmit: any
  onEditDiscard: any
  onHide: any
  show: boolean
  selectedThrottle: any
}
const EditDialog = (props: Iprops) => {
  const methods = useForm<StoreThrottle>(props.selectedThrottle);
  const { handleSubmit, control, register, getValues } = methods;

  return (

    <div>
      <Dialog open={props.show} onClose={props.onEditDiscard} fullWidth={true}>
        <DialogTitle>Editing LOB : {props.selectedThrottle.lob}, Pharmacy : {props.selectedThrottle.pharmID}</DialogTitle>
        <DialogContent>
          <FormInputText {...register('softThrottle', {
            required: "Soft Throttle is required", maxLength: 20,
            pattern: { value: /^[0-9]*$/, message: "Soft Throttle must be a number" }
          })} control={control} label="Soft Throttle *" />
          <FormInputText {...register('hardThrottle', {
            required: "Hard Throttle is required", maxLength: 20,
            pattern: { value: /^[0-9]*$/, message: "Hard Throttle must be a number" }
          })} control={control} label="Hard Throttle *" />
        </DialogContent>
        <DialogActions style={{ justifyContent: "flex-start", padding: '24px' }}>
          <Button style={{ textTransform: "none" }} variant='contained' color="success" onClick={handleSubmit(() => props.onEditSubmit({
            ...props.selectedThrottle,
            softThrottle: getValues('softThrottle'), hardThrottle: getValues('hardThrottle')
          }))}>Save</Button>
          <Button style={{ textTransform: "none" }} variant='contained' color="info" onClick={props.onEditDiscard}>Back</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default EditDialog;
