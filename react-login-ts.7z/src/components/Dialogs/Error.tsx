
import { Typography } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import * as React from 'react';

const ErrorDialog = (props: any) => {
    return (
        <div>
            <Dialog open={props.show} onClose={props.onErrorDiscard}>
                <DialogTitle color={'red'}><i>Error</i></DialogTitle>
                <DialogContent>
                    <Typography variant='subtitle1'> {props.message} </Typography>
                </DialogContent>
                <DialogActions>
                    <Button variant='contained' color='info' onClick={props.onErrorDiscard}>Ok</Button>
                </DialogActions>
            </Dialog>
        </div>
    );
}
export default ErrorDialog;
