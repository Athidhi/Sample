import { MenuItem, TextField } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import * as React from 'react';
import { useForm } from 'react-hook-form';
import { StoreThrottle } from '../../model/throttle';
import { FormInputText } from '../FormElements/FormInputText';
interface Iprops {
    onAddSubmit: any
    onAddDiscard: any
    onHide: any
    show: boolean
    selectedThrottle: any
}
const AddDialog = (props: Iprops) => {
    const methods = useForm<StoreThrottle>();
    const { handleSubmit, control, register, getValues } = methods;

    return (
        <div>
            <Dialog open={props.show} onClose={props.onAddDiscard} fullWidth={true}>
                <DialogTitle><i>Add New Pharmacy Details</i></DialogTitle>
                <DialogContent>
                    <TextField
                        variant='standard'
                        select
                        fullWidth
                        label="Line of Business *"
                        defaultValue='SPECIALTY'
                        inputProps={register('lob', {
                            required: true,
                            maxLength: 10
                        })}
                    >
                        <MenuItem value="SPECIALTY">SPECIALTY</MenuItem>
                        <MenuItem value="RETAIL">RETAIL</MenuItem>
                        <MenuItem value="MAIL">MAIL</MenuItem>
                    </TextField>
                    <FormInputText {...register('pharmID', {
                        required: "Pharmacy ID is required", maxLength: 20
                    }
                    )} control={control} label="Pharmacy ID *" />
                    <FormInputText {...register('softThrottle', {
                        required: "Soft Throttle is required", maxLength: 20,
                        pattern: { value: /^[0-9]*$/, message: "Soft Throttle must be a number" }
                    })} control={control} label="Soft Throttle *" />
                    <FormInputText {...register('hardThrottle', {
                        required: "Hard Throttle is required", maxLength: 20,
                        pattern: { value: /^[0-9]*$/, message: "Hard Throttle must be a number" }
                    })} control={control} label="Hard Throttle *" />
                </DialogContent>
                <DialogActions style={{ justifyContent: "flex-start", padding: '24px' }}>
                    <Button style={{ textTransform: "none" }} variant='contained' color="success" onClick={handleSubmit(props.onAddSubmit)}>Save</Button>
                    <Button style={{ textTransform: "none" }} variant='contained' color="info" onClick={props.onAddDiscard}>Back</Button>
                </DialogActions>
            </Dialog>
        </div>
    );
}

export default AddDialog;
