import { Box, Button, Grid, Table, TableBody, TableCell, TableHead, TableRow } from '@mui/material';
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useEffect, useState } from 'react';
import { useActions } from '../../hooks/useActions';
import { useSelector } from '../../hooks/useTypedSelector';
import { StoreThrottle } from '../../model/throttle';
import AddDialog from '../Dialogs/Add';
import DeleteDialog from '../Dialogs/Delete';
import EditDialog from '../Dialogs/Edit';
import ErrorDialog from '../Dialogs/Error';
import './throttle.css';


const Throttle = () => {

    const [selectedThrottle, setSelectedThrottle] = useState<StoreThrottle>();
    const { getThrottles, EditThrottles, createThrottles, removeThrottles } = useActions();
    const throttles = useSelector((state) => state.throttles);
    const [showEdit, setShowEdit] = useState(false);
    const [showAdd, setShowAdd] = useState(false);
    const [showError, setShowError] = useState("");
    const [showDelete, setShowDelete] = useState({});
    useEffect(() => {
        if (throttles.isEditSuccess || throttles.isAddSuccesss || throttles.isDeleteSuccess)
            getThrottles();
    }, [throttles.isEditSuccess, throttles.isAddSuccesss, throttles.isDeleteSuccess])
    useEffect(() => {
        getThrottles();
    }, [])
    const onEditClick = (throttle: StoreThrottle) => {
        setShowEdit(true);
        setSelectedThrottle(throttle);
    }
    const onEditSubmit = (throttle: StoreThrottle) => {
        EditThrottles(throttle);
        setShowEdit(false);
    }
    const onEditDiscard = () => {
        setShowEdit(false);
    }
    const onAddClick = () => {
        setShowAdd(true);
    }
    const onAddSubmit = (throttle: StoreThrottle) => {
        setShowAdd(false);
        if (throttles.data.findIndex(th => th.pharmID + th.lob === throttle.pharmID + throttle.lob) !== -1) {
            setShowError("Throttle values already exist for the LOB and PharmacyID combination. Please edit instead of adding.");
        }
        else {
            createThrottles(throttle);
            console.log("addin throttle", throttle)
        }


    }
    const onAddDiscard = () => {
        setShowAdd(false);
    }
    const onErrorDiscard = () => {
        setShowError("");
    }
    const onDeleteClick = (throttle: StoreThrottle) => {
        setShowDelete(throttle);
    }
    const onDeleteSubmit = (throttle: StoreThrottle) => {
        removeThrottles(throttle);
        setShowDelete({});
    }
    const onDeleteDiscard = () => {
        setShowDelete({})
    }
    return (
        <>
            {showEdit &&
                <EditDialog
                    onEditSubmit={onEditSubmit}
                    onEditDiscard={onEditDiscard}
                    onHide={onEditDiscard}
                    show={showEdit}
                    selectedThrottle={selectedThrottle}
                />}
            {showAdd &&
                <AddDialog
                    onAddSubmit={onAddSubmit}
                    onAddDiscard={onAddDiscard}
                    onHide={onAddDiscard}
                    show={showAdd}
                    selectedThrottle={selectedThrottle}
                />}
            {showError !== "" &&
                <ErrorDialog
                    onErrorDiscard={onErrorDiscard}
                    onHide={onErrorDiscard}
                    show={showError !== ""}
                    message={showError}
                />}
            {Object.keys(showDelete).length !== 0 &&
                <DeleteDialog
                    onDeleteSubmit={onDeleteSubmit}
                    onDeleteDiscard={onDeleteDiscard}
                    onHide={onDeleteDiscard}
                    show={Object.keys(showDelete).length !== 0}
                    data={showDelete}
                />}
            <Box sx={{ flexGrow: 1, width: 'auto' }}>
                <Grid container spacing={3} sx={{ margin: '1% 13%', width: 'auto' }}>
                    <Grid item xs>
                        <Button color="success" id="refresh" variant='contained'>Refresh</Button>
                    </Grid>
                    <Grid item xs={6} sx={{ textAlign: 'center' }}>
                        <strong style={{ fontSize: '24px', color: 'blue' }}>Pharmacy Throttle Details</strong>
                    </Grid>
                    <Grid item xs sx={{ textAlign: 'end' }}>
                        <span style={{ fontSize: '16px' }} className="text-primary"><strong>{"currentUser"}</strong></span><br />
                        <Button id="logout" color="info" variant='contained'>Logout</Button>
                    </Grid>
                </Grid>
            </Box>

            <br />
            <Table className="table table-hover table-bordered" style={{ margin: 'auto', width: 'auto' }}>
                <TableHead>
                    <TableRow>
                        <th>Line of Business</th>
                        <th>Pharmacy ID</th>
                        <th>Soft Throttle</th>
                        <th>Hard Throttle</th>
                        <th>Last Updated Date</th>
                        <th>Last Updated by</th>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {throttles.data.map(throttle => (
                        <TableRow key={throttle.pharmID + throttle.lob}>
                            <TableCell>{throttle.lob}</TableCell>
                            <TableCell>{throttle.pharmID}</TableCell>
                            <TableCell>{throttle.softThrottle}</TableCell>
                            <TableCell>{throttle.hardThrottle}</TableCell>
                            <TableCell>{throttle.lastUpdatedDate}</TableCell>
                            <TableCell>{throttle.lastUpdatedBy}</TableCell>
                            <TableCell><Button id="edit" variant='contained' color='success' onClick={() => onEditClick(throttle)}>Edit</Button></TableCell>
                            <TableCell><Button id="delete" variant='contained' color='error' onClick={() => onDeleteClick(throttle)}>Delete</Button></TableCell>
                        </TableRow>
                    ))}

                </TableBody >

            </Table >
            <div style={{ marginTop: '2%', width: 'auto', textAlign: 'center' }}>
                <Button id="add" variant='contained' color='success' onClick={onAddClick}>Add</Button>
            </div>
        </>
    )
}
export default Throttle;