import { TextField } from "@mui/material";
import React from "react";
import { Controller } from "react-hook-form";
import { FormInputProps } from "./FormInputProps";

export const FormInputText = React.forwardRef(({ name, control, label, setValue }: FormInputProps, ref) => (
    <Controller
      name={name}
      control={control}
      render={({
        field: { onChange, value, ref },
        fieldState: { error },
        formState,
      }) => (
        <TextField
          helperText={error ? error.message : null}
          size="small"
          error={!!error}
          onChange={onChange}
          fullWidth
          label={label}
          variant="standard"
          defaultValue={setValue}
          inputRef={ref}
          style={{marginTop: '15px'}}
        />
      )}
    />
  ));