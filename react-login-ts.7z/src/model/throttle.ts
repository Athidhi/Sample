export interface StoreThrottle{
	 pharmID: string;
	 lob: string;
	 softThrottle: string;
	 hardThrottle: string;
	 lastUpdatedDate: string;
	 lastUpdatedBy: string;
	 activeDate: string;
	 isActive: boolean;
}