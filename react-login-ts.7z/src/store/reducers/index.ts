import { combineReducers } from "redux";
import loginReducer from "./loginReducer";
import throttleReducer from "./throttleReducer";

const reducers = combineReducers({
  login: loginReducer,
  throttles: throttleReducer,
});

export default reducers;

// initializing root state type similar to our main reducer
export type RootState = ReturnType<typeof reducers>;
