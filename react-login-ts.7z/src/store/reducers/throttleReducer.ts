import { StoreThrottle } from "../../model/throttle";
import { CreateThrottleActionType, EditThrottleActionType, GetThrottleActionType, RemoveThrottleActionType } from "../action-types";
import { ThrottleAction } from '../actions'

interface throttleState {
    loading: boolean;
    error: string | null;
    data: StoreThrottle[];
    isEditSuccess: boolean;
    isAddSuccesss: boolean;
    isDeleteSuccess: boolean;
}

const initialState: throttleState = {
    loading: false,
    error: null,
    data: [],
    isEditSuccess: false,
    isAddSuccesss: false,
    isDeleteSuccess: false
};

const throttleReducer = (
    state: throttleState = initialState,
    action: ThrottleAction
): throttleState => {
    switch (action.type) {
        case GetThrottleActionType.GET_THROTTLE:
            return {
                ...state,
                loading: true,
                error: null,
                data: [],
            };
        case GetThrottleActionType.GET_THROTTLE_SUCCESS:
            return {
                ...state,
                loading: false,
                error: null,
                data: action.payload,
                isEditSuccess: false,
                isAddSuccesss: false,
                isDeleteSuccess: false
            };
        case GetThrottleActionType.GET_THROTTLE_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload,
                data: [],
                isEditSuccess: false,
                isAddSuccesss: false,
                isDeleteSuccess: false
            };
        case CreateThrottleActionType.CREATE_THROTTLE:
            return {
                ...state,
                loading: true,
                error: null,
                isAddSuccesss: false
            };
        case CreateThrottleActionType.CREATE_THROTTLE_SUCCESS:
            return {
                ...state,
                loading: false,
                error: null,
                isAddSuccesss: true
            };
        case CreateThrottleActionType.CREATE_THROTTLE_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload,
                isAddSuccesss: false
            };
        case EditThrottleActionType.EDIT_THROTTLE:
            return {
                ...state,
                loading: true,
                error: null,
                isEditSuccess: false
            };
        case EditThrottleActionType.EDIT_THROTTLE_SUCCESS:
            return {
                ...state,
                loading: false,
                error: null,
                isEditSuccess: true
            };
        case EditThrottleActionType.EDIT_THROTTLE_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload,
                isEditSuccess: false
            };
        case RemoveThrottleActionType.REMOVE_THROTTLE:
            return {
                ...state,
                loading: true,
                error: null,
                isDeleteSuccess: false
            };
        case RemoveThrottleActionType.REMOVE_THROTTLE_SUCCESS:
            return {
                ...state,
                loading: false,
                error: null,
                isDeleteSuccess: true
            };
        case RemoveThrottleActionType.REMOVE_THROTTLE_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload,
                isDeleteSuccess: false
            };
        default:
            return state;
    }
};

export default throttleReducer;
