// exporting everything from the store file
export * from "./store";
// exporting all the action creators
export * as actionCreators from "./action-creators";
// exporting everything from reducers
export * from "./reducers";
