import { Dispatch } from "redux";
import { StoreThrottle } from '../../model/throttle';
import { CreateThrottleActionType, EditThrottleActionType, GetThrottleActionType, RemoveThrottleActionType } from "../action-types";
import { CreateAction, EditAction, GetAction, RemoveAction } from "../actions";

export const getThrottles = () => async (
    dispatch: Dispatch<GetAction>
) => {
    console.log("get----------")
    dispatch({
        type: GetThrottleActionType.GET_THROTTLE,
    });

    try {
        // const { data } = await axios.get(
        //   "http://registry.npmjs.com/-/v1/search?text=" + term
        // );

        // const names = data.objects.map((result: any) => result.package.name);
        let a = [{
            pharmID: "pid",
            lob: "RETAIL",
            softThrottle: "11",
            hardThrottle: "22",
            lastUpdatedDate: "udate",
            lastUpdatedBy: "uby",
            activeDate: "actdate",
            isActive: true
        }]
        dispatch({
            type: GetThrottleActionType.GET_THROTTLE_SUCCESS,
            payload: a,
        });
    } catch (error: any) {
        dispatch({
            type: GetThrottleActionType.GET_THROTTLE_ERROR,
            payload: error.message,
        });
    }
};


export const createThrottles = (throttle: StoreThrottle) => async (
    dispatch: Dispatch<CreateAction>
) => {
    dispatch({
        type: CreateThrottleActionType.CREATE_THROTTLE,
        payload: throttle
    });

    try {
        // const { data } = await axios.get(
        //   "http://registry.npmjs.com/-/v1/search?text=" + term
        // );

        // const names = data.objects.map((result: any) => result.package.name);
        console.log("Create action creator", throttle)
        let a = [{
            pharmID: "pid",
            lob: "lob",
            softThrottle: "12",
            hardThrottle: "14",
            lastUpdatedDate: "udate",
            lastUpdatedBy: "uby",
            activeDate: "actdate",
            isActive: true
        }]
        dispatch({
            type: CreateThrottleActionType.CREATE_THROTTLE_SUCCESS,
            payload: "",
        });
        // const dispatch = useDispatch();

    } catch (error: any) {
        dispatch({
            type: CreateThrottleActionType.CREATE_THROTTLE_ERROR,
            payload: error.message,
        });
    }
};


export const EditThrottles = (throttle: StoreThrottle) => async (
    dispatch: Dispatch<EditAction | GetAction>
) => {
    dispatch({
        type: EditThrottleActionType.EDIT_THROTTLE,
        payload: throttle
    });

    try {
        // const { data } = await axios.get(
        //   "http://registry.npmjs.com/-/v1/search?text=" + term
        // );

        // const names = data.objects.map((result: any) => result.package.name);
        let a = [{
            pharmID: "pid",
            lob: "lob",
            softThrottle: "12",
            hardThrottle: "13",
            lastUpdatedDate: "udate",
            lastUpdatedBy: "uby",
            activeDate: "actdate",
            isActive: true
        }]
        console.log(throttle)
        dispatch({
            type: EditThrottleActionType.EDIT_THROTTLE_SUCCESS,
            payload: "",
        });

        // getThrottles();
    } catch (error: any) {
        dispatch({
            type: EditThrottleActionType.EDIT_THROTTLE_ERROR,
            payload: error.message,
        });
    }
};


export const removeThrottles = (throttle: StoreThrottle | number) => async (
    dispatch: Dispatch<RemoveAction>
) => {
    dispatch({
        type: RemoveThrottleActionType.REMOVE_THROTTLE,
        payload: throttle
    });

    try {
        console.log("remove", throttle)
        let delurl = '/throttle/delete';
        const id = typeof throttle === 'number' ? throttle : (throttle.pharmID + throttle.lob);
        const url = `${delurl}/${id}`;
        // const { data } = await axios.get(
        //   "http://registry.npmjs.com/-/v1/search?text=" + term
        // );

        // const names = data.objects.map((result: any) => result.package.name);
        let a = [{
            pharmID: "pid",
            lob: "lob",
            softThrottle: "soft",
            hardThrottle: "hard",
            lastUpdatedDate: "udate",
            lastUpdatedBy: "uby",
            activeDate: "actdate",
            isActive: true
        }]
        dispatch({
            type: RemoveThrottleActionType.REMOVE_THROTTLE_SUCCESS,
            payload: "Removal Success",
        });
        getThrottles();
    } catch (error: any) {
        dispatch({
            type: RemoveThrottleActionType.REMOVE_THROTTLE_ERROR,
            payload: error.message,
        });
    }
};
