import { StoreThrottle } from "../../model/throttle";
import { GetThrottleActionType, CreateThrottleActionType, RemoveThrottleActionType, EditThrottleActionType } from "../action-types";

interface GetThrottleAction {
    type: GetThrottleActionType.GET_THROTTLE;
}

interface GetThrottleSuccessAction {
    type: GetThrottleActionType.GET_THROTTLE_SUCCESS;
    payload: StoreThrottle[];
}

interface GetThrottleErrorAction {
    type: GetThrottleActionType.GET_THROTTLE_ERROR;
    payload: string;
}

//Create--


interface CreateThrottleAction {
    type: CreateThrottleActionType.CREATE_THROTTLE;
    payload: StoreThrottle;
}

interface CreateThrottleSuccessAction {
    type: CreateThrottleActionType.CREATE_THROTTLE_SUCCESS;
    payload: any;
}

interface CreateThrottleErrorAction {
    type: CreateThrottleActionType.CREATE_THROTTLE_ERROR;
    payload: string;
}

//   --Edit

interface EditThrottleAction {
    type: EditThrottleActionType.EDIT_THROTTLE;
    payload: StoreThrottle;
}

interface EditThrottleSuccessAction {
    type: EditThrottleActionType.EDIT_THROTTLE_SUCCESS;
    payload: any;
}

interface EditThrottleErrorAction {
    type: EditThrottleActionType.EDIT_THROTTLE_ERROR;
    payload: string;
}

//--Remove

interface RemoveThrottleAction {
    type: RemoveThrottleActionType.REMOVE_THROTTLE;
    payload: StoreThrottle | number;
}

interface RemoveThrottleSuccessAction {
    type: RemoveThrottleActionType.REMOVE_THROTTLE_SUCCESS;
    payload: any;
}

interface RemoveThrottleErrorAction {
    type: RemoveThrottleActionType.REMOVE_THROTTLE_ERROR;
    payload: string;
}
export type GetAction =
    | GetThrottleAction
    | GetThrottleSuccessAction
    | GetThrottleErrorAction;

export type CreateAction =
    | CreateThrottleAction
    | CreateThrottleSuccessAction
    | CreateThrottleErrorAction;

export type EditAction =
    | EditThrottleAction
    | EditThrottleSuccessAction
    | EditThrottleErrorAction;

export type RemoveAction =
    | RemoveThrottleAction
    | RemoveThrottleSuccessAction
    | RemoveThrottleErrorAction;

export type ThrottleAction = CreateAction | EditAction | GetAction | RemoveAction;
